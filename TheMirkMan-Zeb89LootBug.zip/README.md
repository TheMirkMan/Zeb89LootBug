the amount of pain i've been through trying to change only one mp3 and after discovering i could do everything with "CustomSounds" is uninmaginable.

This mod Replaces the loot bug sounds with some clips of famous arezzo's youtuber zeb89.

as of now the mod is incomplete, it doesn't have all of the iconic phrases. if you have suggestions i am happy to take them.

i want to be clear tho, this mod does not want to defamate in any way Zeb89 nor mock him. it's just some fun thing my mind gave birth to.
```
[Info   :Zeb89LootBug] @@@@@
                    @       @@
                   @   @@@      @@@
                  @  @@@ @           @@@
                  @     @@                @@@
                 @                            @@@
                @                                  @@
               @                                     @
               @                                     @
              @                                     @
             @                                      @
             @               @                     @          @@@@
            @               @@@@@@@               @         @       @
           @               @@@ @@@@              @@         @   @   @
          @       @@@@     @@@  @@               @          @   @   @
          @      @@@@@@@@@@@@@@@@               @           @   @   @ @@     @@ @      @@
         @      @@@@  @@@@@@@@@@               @            @   @   @ @   @   @ @   @  @@
        @       @@@@@@@@@@@@@@@@@@@@           @            @       @ @   @   @ @   @  @@
       @@            @@@@@@@@@@@@@ @@@@@      @             @   @   @ @   @   @ @   @  @@
       @               @@@@@@@@@@@  @@@      @              @   @   @ @   @@@@@ @   @  @@
      @               @@@@@@@@ @@@@@@@      @@              @   @   @ @   @   @ @      @@
     @               @@@   @@      @@@      @               @   @   @ @   @   @ @   @@@@@
     @               @@@@@@@               @    @@@@@@@@    @   @   @ @       @ @       @
    @                 @@@@@@              @    @       @    @@@@@@@@@  @@@@@@@   @@@@@@@@
   @@                                     @    @   @   @
  @@                                     @     @   @   @ @@@@@@@   @@@@@@@@@@@    @@@@@    @@@@@@@
  @                                     @      @   @   @ @       @ @          @@@@      @ @      @
  @                                    @       @   @@@@@ @@@@@   @ @  @@  @@  @ @   @   @ @   @@@@
   @@@@                                @       @   @   @ @       @ @  @@  @@  @ @   @   @ @   @
       @@@                            @        @   @   @ @   @   @ @  @@  @@  @ @   @   @ @   @
           @@@@              @@ @@   @         @   @   @ @   @   @ @  @@  @@  @ @   @   @ @   @
                @@@@        @@ @@@  @@         @   @   @ @   @   @ @  @@  @@  @ @       @ @   @
                     @@@      @@@   @          @   @   @ @   @   @ @  @@  @@  @ @   @@@@@ @   @   @
                          @@@      @           @       @ @       @ @  @@  @@  @@@@      @ @@@@@  @@@
                              @@@@@

[Info   :Zeb89LootBug] POPO FIERO!
```
//this was in the Logger.something() in my cs project. it was cool so i want to keep it.
