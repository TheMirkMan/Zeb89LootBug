--------*1.0.2*------------
-added more zeb89 references, such as
 1)panino al salame
 2)eh! volevi!
 3)ace gamer music
added two fly.wavs

-------*1.0.3*------------
just changed the percentual of some .Wav

-------*1.0.4*-------------
reorganized package because i'm a dumbass