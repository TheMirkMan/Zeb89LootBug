-added more zeb89 references, such as
 1)panino al salame
 2)eh! volevi!
 3)ace gamer music
added two fly.wavs